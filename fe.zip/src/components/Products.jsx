import React, { useState } from 'react';
import { Button } from '@/components/ui/button';

const products = [
  {
    id: 1,
    name: 'Cuplock Ledger & Standards',
    description: 'Heavy-duty modular scaffolding system for fast and secure installation on any construction site.',
    image: 'https://images.unsplash.com/photo-1619486219569-ecd80122d117?crop=entropy&cs=srgb&fm=jpg&ixid=M3w3NDk1Nzd8MHwxfHNlYXJjaHwzfHxzY2FmZm9sZGluZyUyMGNvbnN0cnVjdGlvbnxlbnwwfHx8fDE3Njk3ODQxMzN8MA&ixlib=rb-4.1.0&q=85',
    features: ['Quick assembly', 'High load capacity', 'Durable finish'],
    category: 'scaffolding',
  },
  {
    id: 2,
    name: 'Adjustable Props',
    description: 'Versatile steel props with adjustable height for temporary support during construction.',
    image: 'https://images.pexels.com/photos/154141/pexels-photo-154141.jpeg',
    features: ['Height adjustable', 'Heavy duty', 'Rust resistant'],
    category: 'props',
  },
  {
    id: 3,
    name: 'Base Jack & U Head Jack',
    description: 'Essential foundation components for stable and level scaffolding setup.',
    image: 'https://images.unsplash.com/photo-1741916541913-7203d2be5e6e?crop=entropy&cs=srgb&fm=jpg&ixid=M3w3NDk1ODB8MHwxfHNlYXJjaHwyfHxtZXRhbCUyMHNjYWZmb2xkaW5nfGVufDB8fHx8MTc2OTc4NDEzOHww&ixlib=rb-4.1.0&q=85',
    features: ['Precision leveling', 'Strong base', 'Universal fit'],
    category: 'props',
  },
  {
    id: 4,
    name: 'MS Planks',
    description: 'Quality metal scaffolding planks providing safe and sturdy walking platforms.',
    image: 'https://images.unsplash.com/photo-1761973673877-3139d1eae106?crop=entropy&cs=srgb&fm=jpg&ixid=M3w4NTYxNzV8MHwxfHNlYXJjaHw0fHxtZXRhbCUyMHNjYWZmb2xkaW5nfGVufDB8fHx8MTc2OTc4NDEzOHww&ixlib=rb-4.1.0&q=85',
    features: ['Anti-slip surface', 'High strength', 'Standard sizes'],
    category: 'scaffolding',
  },
  {
    id: 5,
    name: 'H-Frames',
    description: 'Portable and easy-to-assemble frames ideal for low to medium height applications.',
    image: 'https://images.pexels.com/photos/31745718/pexels-photo-31745718.jpeg',
    features: ['Lightweight', 'Quick setup', 'Stackable design'],
    category: 'frames',
  },
  {
    id: 6,
    name: 'Shuttering Plates & Beams',
    description: 'High-quality formwork systems for concrete casting and slab construction.',
    image: 'https://images.unsplash.com/photo-1626885930974-4b69aa21bbf9?crop=entropy&cs=srgb&fm=jpg&ixid=M3w4NTYxNzV8MHwxfHNlYXJjaHw0fHxjb25zdHJ1Y3Rpb24lMjB3b3JrZXJzfGVufDB8fHx8MTc2OTc4NDE0NXww&ixlib=rb-4.1.0&q=85',
    features: ['Smooth finish', 'Reusable', 'Multiple sizes'],
    category: 'shuttering',
  },
];

const categories = [
  { id: 'all', name: 'All Products' },
  { id: 'scaffolding', name: 'Scaffolding' },
  { id: 'props', name: 'Props & Jacks' },
  { id: 'frames', name: 'Frames' },
  { id: 'shuttering', name: 'Shuttering' },
];

export const Products = () => {
  const [activeCategory, setActiveCategory] = useState('all');

  const filteredProducts = activeCategory === 'all' 
    ? products 
    : products.filter(p => p.category === activeCategory);

  return (
    <section id="products" className="py-20 lg:py-32 bg-white relative overflow-hidden">
      {/* Background Pattern */}
      <div className="absolute inset-0 pattern-dots opacity-50"></div>

      <div className="container mx-auto px-4 lg:px-8 relative">
        {/* Section Header */}
        <div className="text-center mb-12">
          <span className="inline-block text-accent font-semibold text-sm tracking-wider uppercase mb-4">
            Our Products
          </span>
          <h2 className="text-3xl lg:text-4xl font-bold text-foreground mb-6 font-heading">
            Quality Scaffolding <span className="text-accent">Equipment</span>
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto text-base lg:text-lg">
            We supply well-maintained, safety-checked materials following strict quality standards
            to ensure reliable performance on every project.
          </p>
        </div>

        {/* Category Filter */}
        <div className="flex flex-wrap justify-center gap-3 mb-12">
          {categories.map((category) => (
            <button
              key={category.id}
              onClick={() => setActiveCategory(category.id)}
              className={`px-5 py-2.5 rounded-full text-sm font-medium transition-all ${
                activeCategory === category.id
                  ? 'bg-primary text-primary-foreground shadow-md'
                  : 'bg-muted text-muted-foreground hover:bg-muted/80'
              }`}
            >
              {category.name}
            </button>
          ))}
        </div>

        {/* Products Grid */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredProducts.map((product, index) => (
            <div
              key={product.id}
              className="group bg-white rounded-2xl overflow-hidden shadow-card hover-lift border border-border/50"
              style={{ animationDelay: `${index * 100}ms` }}
            >
              {/* Product Image */}
              <div className="relative h-56 overflow-hidden">
                <img
                  src={product.image}
                  alt={product.name}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-primary/60 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                
                {/* Quick View Button */}
                <div className="absolute bottom-4 left-4 right-4 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                  <Button variant="white" className="w-full">
                    <i className="fas fa-eye mr-2"></i>
                    View Details
                  </Button>
                </div>
              </div>

              {/* Product Info */}
              <div className="p-6">
                <h3 className="text-lg font-bold text-foreground mb-2 group-hover:text-accent transition-colors">
                  {product.name}
                </h3>
                <p className="text-sm text-muted-foreground mb-4 line-clamp-2">
                  {product.description}
                </p>

                {/* Features */}
                <div className="flex flex-wrap gap-2 mb-4">
                  {product.features.map((feature, idx) => (
                    <span
                      key={idx}
                      className="text-xs px-3 py-1 rounded-full bg-accent/10 text-accent font-medium"
                    >
                      {feature}
                    </span>
                  ))}
                </div>

                {/* CTA */}
                <Button variant="outline" className="w-full group-hover:bg-accent group-hover:text-white group-hover:border-accent transition-colors">
                  <i className="fas fa-phone-alt mr-2"></i>
                  Enquire Now
                </Button>
              </div>
            </div>
          ))}
        </div>

        {/* Bottom CTA */}
        <div className="mt-16 text-center">
          <p className="text-muted-foreground mb-6">
            Looking for specific equipment? We have a wide range of scaffolding solutions.
          </p>
          <Button variant="premium" size="xl">
            <i className="fas fa-file-alt mr-2"></i>
            Download Full Catalog
          </Button>
        </div>
      </div>
    </section>
  );
};
